﻿namespace Pexeso
{
    partial class OknoPexeso
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pictureBox1_lic = new System.Windows.Forms.PictureBox();
            this.pictureBox4_lic = new System.Windows.Forms.PictureBox();
            this.pictureBox3_lic = new System.Windows.Forms.PictureBox();
            this.pictureBox2_lic = new System.Windows.Forms.PictureBox();
            this.label_Score = new System.Windows.Forms.Label();
            this.pictureBox6_lic = new System.Windows.Forms.PictureBox();
            this.pictureBox7_lic = new System.Windows.Forms.PictureBox();
            this.pictureBox8_lic = new System.Windows.Forms.PictureBox();
            this.pictureBox5_lic = new System.Windows.Forms.PictureBox();
            this.label_score_popis = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.hraToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.novaHraToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.konecToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.hraciToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.HelpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.infoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1_lic)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4_lic)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3_lic)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2_lic)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6_lic)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7_lic)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8_lic)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5_lic)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // pictureBox1_lic
            // 
            this.pictureBox1_lic.AccessibleName = "Sekery";
            this.pictureBox1_lic.BackColor = System.Drawing.Color.White;
            this.pictureBox1_lic.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pictureBox1_lic.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox1_lic.InitialImage = null;
            this.pictureBox1_lic.Location = new System.Drawing.Point(83, 167);
            this.pictureBox1_lic.Name = "pictureBox1_lic";
            this.pictureBox1_lic.Padding = new System.Windows.Forms.Padding(2);
            this.pictureBox1_lic.Size = new System.Drawing.Size(115, 110);
            this.pictureBox1_lic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1_lic.TabIndex = 0;
            this.pictureBox1_lic.TabStop = false;
            this.pictureBox1_lic.Tag = "1";
            this.pictureBox1_lic.WaitOnLoad = true;
            this.pictureBox1_lic.Click += new System.EventHandler(this.pictureBox_Click);
            // 
            // pictureBox4_lic
            // 
            this.pictureBox4_lic.BackColor = System.Drawing.Color.White;
            this.pictureBox4_lic.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pictureBox4_lic.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox4_lic.InitialImage = null;
            this.pictureBox4_lic.Location = new System.Drawing.Point(539, 167);
            this.pictureBox4_lic.Name = "pictureBox4_lic";
            this.pictureBox4_lic.Padding = new System.Windows.Forms.Padding(2);
            this.pictureBox4_lic.Size = new System.Drawing.Size(115, 110);
            this.pictureBox4_lic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4_lic.TabIndex = 2;
            this.pictureBox4_lic.TabStop = false;
            this.pictureBox4_lic.Tag = "4";
            this.pictureBox4_lic.WaitOnLoad = true;
            this.pictureBox4_lic.Click += new System.EventHandler(this.pictureBox_Click);
            // 
            // pictureBox3_lic
            // 
            this.pictureBox3_lic.BackColor = System.Drawing.Color.White;
            this.pictureBox3_lic.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pictureBox3_lic.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox3_lic.InitialImage = global::Pexeso.Properties.Resources._030_wooden_mug;
            this.pictureBox3_lic.Location = new System.Drawing.Point(384, 167);
            this.pictureBox3_lic.Name = "pictureBox3_lic";
            this.pictureBox3_lic.Padding = new System.Windows.Forms.Padding(2);
            this.pictureBox3_lic.Size = new System.Drawing.Size(115, 110);
            this.pictureBox3_lic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3_lic.TabIndex = 4;
            this.pictureBox3_lic.TabStop = false;
            this.pictureBox3_lic.Tag = "3";
            this.pictureBox3_lic.Click += new System.EventHandler(this.pictureBox_Click);
            // 
            // pictureBox2_lic
            // 
            this.pictureBox2_lic.BackColor = System.Drawing.Color.White;
            this.pictureBox2_lic.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pictureBox2_lic.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox2_lic.InitialImage = global::Pexeso.Properties.Resources._030_wooden_mug;
            this.pictureBox2_lic.Location = new System.Drawing.Point(231, 167);
            this.pictureBox2_lic.Name = "pictureBox2_lic";
            this.pictureBox2_lic.Padding = new System.Windows.Forms.Padding(2);
            this.pictureBox2_lic.Size = new System.Drawing.Size(115, 110);
            this.pictureBox2_lic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2_lic.TabIndex = 6;
            this.pictureBox2_lic.TabStop = false;
            this.pictureBox2_lic.Tag = "2";
            this.pictureBox2_lic.WaitOnLoad = true;
            this.pictureBox2_lic.Click += new System.EventHandler(this.pictureBox_Click);
            // 
            // label_Score
            // 
            this.label_Score.AutoSize = true;
            this.label_Score.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_Score.Location = new System.Drawing.Point(273, 98);
            this.label_Score.Name = "label_Score";
            this.label_Score.Size = new System.Drawing.Size(93, 32);
            this.label_Score.TabIndex = 7;
            this.label_Score.Text = "label1";
            // 
            // pictureBox6_lic
            // 
            this.pictureBox6_lic.AccessibleName = "Sekery";
            this.pictureBox6_lic.BackColor = System.Drawing.Color.White;
            this.pictureBox6_lic.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pictureBox6_lic.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox6_lic.InitialImage = null;
            this.pictureBox6_lic.Location = new System.Drawing.Point(231, 314);
            this.pictureBox6_lic.Name = "pictureBox6_lic";
            this.pictureBox6_lic.Padding = new System.Windows.Forms.Padding(2);
            this.pictureBox6_lic.Size = new System.Drawing.Size(115, 110);
            this.pictureBox6_lic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox6_lic.TabIndex = 12;
            this.pictureBox6_lic.TabStop = false;
            this.pictureBox6_lic.Tag = "6";
            this.pictureBox6_lic.WaitOnLoad = true;
            this.pictureBox6_lic.Click += new System.EventHandler(this.pictureBox_Click);
            // 
            // pictureBox7_lic
            // 
            this.pictureBox7_lic.AccessibleName = "Sekery";
            this.pictureBox7_lic.BackColor = System.Drawing.Color.White;
            this.pictureBox7_lic.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pictureBox7_lic.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox7_lic.InitialImage = null;
            this.pictureBox7_lic.Location = new System.Drawing.Point(384, 314);
            this.pictureBox7_lic.Name = "pictureBox7_lic";
            this.pictureBox7_lic.Padding = new System.Windows.Forms.Padding(2);
            this.pictureBox7_lic.Size = new System.Drawing.Size(115, 110);
            this.pictureBox7_lic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox7_lic.TabIndex = 14;
            this.pictureBox7_lic.TabStop = false;
            this.pictureBox7_lic.Tag = "7";
            this.pictureBox7_lic.WaitOnLoad = true;
            this.pictureBox7_lic.Click += new System.EventHandler(this.pictureBox_Click);
            // 
            // pictureBox8_lic
            // 
            this.pictureBox8_lic.AccessibleName = "Sekery";
            this.pictureBox8_lic.BackColor = System.Drawing.Color.White;
            this.pictureBox8_lic.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pictureBox8_lic.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox8_lic.InitialImage = null;
            this.pictureBox8_lic.Location = new System.Drawing.Point(539, 314);
            this.pictureBox8_lic.Name = "pictureBox8_lic";
            this.pictureBox8_lic.Padding = new System.Windows.Forms.Padding(2);
            this.pictureBox8_lic.Size = new System.Drawing.Size(115, 110);
            this.pictureBox8_lic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox8_lic.TabIndex = 16;
            this.pictureBox8_lic.TabStop = false;
            this.pictureBox8_lic.Tag = "0";
            this.pictureBox8_lic.WaitOnLoad = true;
            this.pictureBox8_lic.Click += new System.EventHandler(this.pictureBox_Click);
            // 
            // pictureBox5_lic
            // 
            this.pictureBox5_lic.AccessibleName = "Sekery";
            this.pictureBox5_lic.BackColor = System.Drawing.Color.White;
            this.pictureBox5_lic.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pictureBox5_lic.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox5_lic.InitialImage = null;
            this.pictureBox5_lic.Location = new System.Drawing.Point(83, 314);
            this.pictureBox5_lic.Name = "pictureBox5_lic";
            this.pictureBox5_lic.Padding = new System.Windows.Forms.Padding(2);
            this.pictureBox5_lic.Size = new System.Drawing.Size(115, 110);
            this.pictureBox5_lic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox5_lic.TabIndex = 18;
            this.pictureBox5_lic.TabStop = false;
            this.pictureBox5_lic.Tag = "5";
            this.pictureBox5_lic.WaitOnLoad = true;
            this.pictureBox5_lic.Click += new System.EventHandler(this.pictureBox_Click);
            // 
            // label_score_popis
            // 
            this.label_score_popis.AutoSize = true;
            this.label_score_popis.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_score_popis.Location = new System.Drawing.Point(77, 98);
            this.label_score_popis.Name = "label_score_popis";
            this.label_score_popis.Size = new System.Drawing.Size(178, 32);
            this.label_score_popis.TabIndex = 19;
            this.label_score_popis.Text = "Počet bodů:";
            // 
            // menuStrip1
            // 
            this.menuStrip1.GripMargin = new System.Windows.Forms.Padding(2, 2, 0, 2);
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.hraToolStripMenuItem,
            this.hraciToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(747, 33);
            this.menuStrip1.TabIndex = 20;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // hraToolStripMenuItem
            // 
            this.hraToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.novaHraToolStripMenuItem,
            this.konecToolStripMenuItem});
            this.hraToolStripMenuItem.Name = "hraToolStripMenuItem";
            this.hraToolStripMenuItem.Size = new System.Drawing.Size(56, 29);
            this.hraToolStripMenuItem.Text = "Hra";
            // 
            // novaHraToolStripMenuItem
            // 
            this.novaHraToolStripMenuItem.Name = "novaHraToolStripMenuItem";
            this.novaHraToolStripMenuItem.Size = new System.Drawing.Size(186, 34);
            this.novaHraToolStripMenuItem.Text = "Nova hra";
            this.novaHraToolStripMenuItem.Click += new System.EventHandler(this.novaHraToolStripMenuItem_Click);
            // 
            // konecToolStripMenuItem
            // 
            this.konecToolStripMenuItem.Name = "konecToolStripMenuItem";
            this.konecToolStripMenuItem.Size = new System.Drawing.Size(186, 34);
            this.konecToolStripMenuItem.Text = "Konec";
            this.konecToolStripMenuItem.Click += new System.EventHandler(this.konecToolStripMenuItem_Click);
            // 
            // hraciToolStripMenuItem
            // 
            this.hraciToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.HelpToolStripMenuItem,
            this.infoToolStripMenuItem});
            this.hraciToolStripMenuItem.Name = "hraciToolStripMenuItem";
            this.hraciToolStripMenuItem.Size = new System.Drawing.Size(65, 29);
            this.hraciToolStripMenuItem.Text = "Help";
            // 
            // HelpToolStripMenuItem
            // 
            this.HelpToolStripMenuItem.Name = "HelpToolStripMenuItem";
            this.HelpToolStripMenuItem.Size = new System.Drawing.Size(270, 34);
            this.HelpToolStripMenuItem.Text = "Pravidla";
            this.HelpToolStripMenuItem.Click += new System.EventHandler(this.HelpToolStripMenuItem_Click);
            // 
            // infoToolStripMenuItem
            // 
            this.infoToolStripMenuItem.Name = "infoToolStripMenuItem";
            this.infoToolStripMenuItem.Size = new System.Drawing.Size(270, 34);
            this.infoToolStripMenuItem.Text = "O aplikaci";
            this.infoToolStripMenuItem.Click += new System.EventHandler(this.infoToolStripMenuItem_Click);
            // 
            // OknoPexeso
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(747, 929);
            this.Controls.Add(this.label_score_popis);
            this.Controls.Add(this.pictureBox5_lic);
            this.Controls.Add(this.pictureBox8_lic);
            this.Controls.Add(this.pictureBox7_lic);
            this.Controls.Add(this.pictureBox6_lic);
            this.Controls.Add(this.label_Score);
            this.Controls.Add(this.pictureBox2_lic);
            this.Controls.Add(this.pictureBox3_lic);
            this.Controls.Add(this.pictureBox4_lic);
            this.Controls.Add(this.pictureBox1_lic);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "OknoPexeso";
            this.Text = "Pexeso";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1_lic)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4_lic)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3_lic)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2_lic)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6_lic)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7_lic)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8_lic)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5_lic)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        protected internal System.Windows.Forms.PictureBox pictureBox1_lic;
        protected internal System.Windows.Forms.PictureBox pictureBox4_lic;
        protected internal System.Windows.Forms.PictureBox pictureBox3_lic;
        protected internal System.Windows.Forms.PictureBox pictureBox2_lic;
        private System.Windows.Forms.Label label_Score;
        protected internal System.Windows.Forms.PictureBox pictureBox6_lic;
        protected internal System.Windows.Forms.PictureBox pictureBox7_lic;
        protected internal System.Windows.Forms.PictureBox pictureBox8_lic;
        protected internal System.Windows.Forms.PictureBox pictureBox5_lic;
        private System.Windows.Forms.Label label_score_popis;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem hraToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem novaHraToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem konecToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem hraciToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem HelpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem infoToolStripMenuItem;
    }
}

